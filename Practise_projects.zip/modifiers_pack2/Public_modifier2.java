package modifiers_pack2;
import modifiers_pack1.Public_modifier;

public class Public_modifier2 {

	public static void main(String args[]){
		Public_modifier m = new Public_modifier();
		m.display();
	}
}
