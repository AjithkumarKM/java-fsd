package modifiers_pack2;
import modifiers_pack1.Protected_modifier;

public class Protected_modifier2 extends Protected_modifier{

	public static void main(String args[]){
		Protected_modifier2 m = new Protected_modifier2();
		m.display();
	}
}
