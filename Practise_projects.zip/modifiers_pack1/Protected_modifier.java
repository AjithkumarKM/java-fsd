package modifiers_pack1;

public class Protected_modifier {

	protected void display(){
		System.out.println("Accessing protected method from another package");
	}
}
