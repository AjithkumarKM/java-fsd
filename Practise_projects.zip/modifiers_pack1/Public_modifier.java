package modifiers_pack1;

public class Public_modifier {

	public void display(){
		System.out.println("Accessing public method from another package");		
	}

}
