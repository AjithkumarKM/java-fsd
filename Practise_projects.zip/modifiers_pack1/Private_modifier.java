package modifiers_pack1;

class privateModifier{
	private  void display(){
		System.out.println("Accessing the private method from default methof");
	}
	void display2(){
		System.out.println("Inside the default method");
		display();
	}
	
}

public class Private_modifier {

	public static void main(String args[]){
		privateModifier m = new privateModifier();
		// m.display(); -> cannot be accessed
		
		m.display2();
	}
}
