package modifiers_pack1;

class defaultMethod{
	void display(){
		System.out.println("Inside the default modifier");
	}
}

public class Default_modifier {

	public static void main(String args[]){
		defaultMethod m = new defaultMethod();
		m.display();
	}
}
