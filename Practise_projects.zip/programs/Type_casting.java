package programs;

public class Type_casting {

	public static void main(String args[]){
		char c = 'A';
		
		int i = c;
		long l = c;
		float f = c;
		double d = c;
		
		System.out.println("Implicit Typecasting");
		System.out.println("The character is : " + c);
		System.out.println("Int value is : " + i);
		System.out.println("Long value is : " + l);
		System.out.println("Float value is : " + f);
		System.out.println("Double vlaue is : " + d);
		
		
		double d2 = 95.64354563;
		float f2 = (float)d2;
		long l2 = (long)d2;
		int i2 = (int)d2;
		char c2 = (char)d2;
		
		System.out.println("\nExplicit Typecasting");
		System.out.println("The double value is : " + d2);
		System.out.println("Float value is : " + f2);
		System.out.println("Long value is : " + l2);
		System.out.println("Int value is : " + i2);
		System.out.println("Character vlaue is : " + c2);
		
	}
}
