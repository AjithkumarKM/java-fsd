package programs;
import java.util.*;

public class Collection_maps {

	public static void main(String args[]){
		System.out.println("HAshMap");
		HashMap<Integer,String> books = new HashMap<Integer,String>();
		books.put(1, "Science");
		books.put(2, "Social");
		books.put(4, "Biology");
		books.put(3, "Maths");
		System.out.println(books);
		books.remove(4);
		System.out.println(books);
		
		for(Map.Entry m: books.entrySet()){
			System.out.println(m.getKey() + "  " + m.getValue());
		}
		
		System.out.println("\nHAshTable");
		Hashtable<Integer,String> bookTable = new Hashtable<Integer,String>();
		bookTable.put(1, "Science");
		bookTable.put(2, "Social");
		bookTable.put(4, "Biology");
		bookTable.put(3, "Maths");
		System.out.println(bookTable);
		bookTable.remove(4);
		System.out.println(bookTable);
		bookTable.replace(2, "SocialScience");
		for(Map.Entry m: bookTable.entrySet()){
			System.out.println(m.getKey() + "  " + m.getValue());
		}
		
		System.out.println("\nTreeMap");
		TreeMap<Integer,String> bookTree = new TreeMap<Integer,String>();
		bookTree.put(1, "Science");
		bookTree.put(2, "Social");
		bookTree.put(4, "Biology");
		bookTree.put(5, "Tamil");
		bookTree.put(3, "Maths");
		System.out.println(bookTree);
		bookTree.remove(4);
		System.out.println(bookTree);
		System.out.println(bookTree.get(3));
		for(Map.Entry m: bookTree.entrySet()){
			System.out.println(m.getKey() + "  " + m.getValue());
		}
		
		
	}
}
