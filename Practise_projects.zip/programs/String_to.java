package programs;

public class String_to {

	public static void main(String args[]){
		
		String str1 = "universe is BEAUTIFUL";
		String str2 = "Ajith";
		String str3 = "Kumar";
		String str4 = new String("Kavi");
		String str5 = str4;
		String str6 = new String("Ajith");
		
		System.out.println("Length if str1 is : " + str1.length());
		System.out.println("Char at index 6 is : " + str1.charAt(6));
		System.out.println(str1.toLowerCase());
		System.out.println(str1.toUpperCase());
		System.out.println("Substsing from index 5 to 16 : " + str1.substring(5, 16));
		String replaced = str1.replace("is", "was");
		System.out.println(replaced);
		
		System.out.println("\nComparing str2 with str6");
		System.out.println(str2.equals(str6));
		System.out.println(str2==str6);
		
		System.out.println("\nComparing str4 with str5");
		System.out.println(str4.equals(str5));
		System.out.println(str4==str5);
		
		String combined = str2.concat(str3);
		System.out.println("\nConcat str2 and str3 : " + combined);
		
		
		StringBuffer sb = new StringBuffer(str2);
		System.out.println("\n" + sb);
		sb.append("Kumar");
		System.out.println(sb);
		System.out.println(sb.charAt(6));
		System.out.println(sb.indexOf("r"));
		sb.insert(0, "K");
		System.out.println(sb);
		sb.replace(6, 10, "ramuk");
		System.out.println(sb);
		sb.reverse();
		System.out.println(sb);
		
		StringBuilder sb1 = new StringBuilder(str4);
		System.out.println("\n" + sb1);
		sb1.append(" Arasan");
		System.out.println(sb1);
		System.out.println(sb1.charAt(6));
		System.out.println(sb1.indexOf("r"));
		sb1.insert(0, "R");
		System.out.println(sb1);
		sb1.replace(6, 10, "ramuk");
		System.out.println(sb1);
		sb1.reverse();
		System.out.println(sb1);
	}
}
