package programs;


public class Calling_method {

	int add(int a, int b){
		return a+b;
	}

	public static void main(String args[]){
		Calling_method m = new Calling_method();
		int sum = m.add(5, 3);
		System.out.println("The sum is : " + sum);
	}
}
