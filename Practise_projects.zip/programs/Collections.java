package programs;
import java.util.*;

public class Collections {

	public static void main(String args[]){
		System.out.println("Array List");
		ArrayList<Integer> arr = new ArrayList<Integer>();
		arr.add(5);
		arr.add(7);
		System.out.println(arr);
		int s = arr.size();
		System.out.println("The length of list is " + s);
		arr.add(1, 6);
		System.out.println(arr);
		System.out.println("Index of 7 : " + arr.indexOf(7));
		
		System.out.println("\nVector");
		Vector<Integer> v = new Vector<Integer>();
		v.add(6);
		v.add(3);
		System.out.println(v);
		v.remove(1);
		System.out.println(v);
		
		System.out.println("\nLinked List");
		LinkedList<String> names = new LinkedList<String>();
		names.add("Ajith");
		names.add("Kavi");
		names.add("Priya");
		names.add("Shuruthi");
		System.out.println(names);
		Iterator itr = names.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
		
		System.out.println("\nHashSet");
		HashSet set = new HashSet<>();
		set.add('f');
		set.add('a');
		set.add('c');
		System.out.println(set);
		
		System.out.println("\nLinked hash set");
		LinkedHashSet lset  = new LinkedHashSet<>();
		lset.add('f');
		lset.add('a');
		lset.add('c');
		System.out.println(lset);
		
	}
}
