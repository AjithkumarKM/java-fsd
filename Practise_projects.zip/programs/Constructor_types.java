package programs;

class Addition{
	int a,b;
	void display(){
		System.out.println("Default constructor");		
		System.out.println("The sum is : " + (a+b));
	}
}

class Addition2{
	int a,b;
	void display(int a, int b){
		System.out.println("Parameterized constructor");
		System.out.println("The sum is : " + (a+b));
	}	
}

class Overloading{
	int a,b,c;
	Overloading(){
		a = 1;
		b = 1;
		add();
	}
	Overloading(int a){
		this.a = a;
		this.b = 1;
		add();
	}
	Overloading(int a, int b){
		this.a = a;
		add();
	}
	
	void add(){
		this.c = this.a + this.b;
	}
	
	void display(){

		System.out.println("The sum is : " + this.c);
	}
}

public class Constructor_types {

	public static void main(String args[]){
		
		Addition m = new Addition();
		m.display();
		
		Addition2 m2 = new Addition2();
		m2.display(5,3);

		//Constructor overloading
		System.out.println("\nconstructor overloading");
		Overloading o = new Overloading();
		o.display();
		
		Overloading o2 = new Overloading(5);
		o2.display();
		
		Overloading o3 = new Overloading(5,3);
		o3.display();
		
	}
}
