package programs;

public class Method_overloading {

	void addition(int a, int b){
		System.out.println("The sum is : " + (a+b));
	}
	
	void addition(int a, float b){
		System.out.println("The sum is : " + (a+b));
	}
	
	void addition(int a, int b, int c){
		System.out.println("The sum is : " + (a+b+c));
	}
	
	public static void main(String args[]){
		
		Method_overloading m = new Method_overloading();
		m.addition(4, 7.5f);
		m.addition(5, 3);
		m.addition(3, 5, 10);
	}
}
