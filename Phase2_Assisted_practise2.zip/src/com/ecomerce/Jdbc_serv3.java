package com.ecomerce;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Types;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Jdbc_serv3
 */
public class Jdbc_serv3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	static String url = "jdbc:mysql://localhost:3306/db_world";
    static String user = "root";
    static String password = "root";
    static String sql = "{call cpid(?,?)}";
    static Connection con;
    
    public Jdbc_serv3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		try{
    		try{
    			Class.forName("com.mysql.jdbc.Driver");
    		}
    		catch(Exception e){
    			e.getStackTrace();
    		}
    		
    		con = DriverManager.getConnection(url,user,password);
    		
    		CallableStatement stmt = con.prepareCall(sql);
    		
    		stmt.setInt(1, 1);
    		stmt.setDouble(2, 25.0);
    		stmt.executeUpdate();
    		out.println("updated");
    		
    		stmt.close();
    	}
    	catch(Exception e){
    		e.getStackTrace();
    	}
    	finally{
    		try{
    			con.close();
    		}
    		catch(Exception e){
    			e.getStackTrace();
    		}
    	}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
