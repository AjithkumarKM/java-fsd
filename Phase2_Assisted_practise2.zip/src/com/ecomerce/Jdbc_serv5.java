package com.ecomerce;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Jdbc_serv5
 */
public class Jdbc_serv5 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	static String url = "jdbc:mysql://localhost:3306/db_world";
    static String user = "root";
    static String password = "root";
	static Connection con;
	static PreparedStatement pstmt;
	static ResultSet rs;
	static Statement stmt;
	
    public Jdbc_serv5() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String query = "insert into product (Id,name,price) values (4,'eraser',12.5)";
		String query2 = "update product set price=15.0 where Id=4";
		String query3 = "delete from product where Id=4";
		out.println("hello");
		try{
			try{
				Class.forName("com.mysql.jdbc.Driver");
			}
			catch(ClassNotFoundException e){
				e.getStackTrace();
			}
			
			con = DriverManager.getConnection(url,user,password);
			stmt = con.createStatement();
			stmt.executeUpdate(query);
			out.println("<br>Insertion performed");
			stmt.executeUpdate(query2);
			out.println("<br>updation performed");
			stmt.executeUpdate(query3);
			out.println("<br>deletion performed");
			
		}
		catch(SQLException e){
			e.getStackTrace();
		}
		catch(Exception e){
			e.getStackTrace();
		}
		finally{
			try{
				con.close();
				rs.close();
				stmt.close();
			}
			catch (Exception e){
				e.getStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
