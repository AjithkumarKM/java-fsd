package com.ecomerce;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Jdbc_serv
 */
public class Jdbc_serv extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	private static final String url = "jdbc:mysql://localhost:3306/db_world";
	private static final String user = "root";
	private static final String password = "root";
	
	Connection con;
	
    public Jdbc_serv() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("hello");
		try{
			try{
				out.println("trying");
				Class.forName("com.mysql.jdbc.Driver");
			}
			catch(ClassNotFoundException e){
				e.getStackTrace();
			}
			con = DriverManager.getConnection(url,user,password);
			out.println("<br>connection established");
		}
		catch(Exception e){
			e.getStackTrace();
		}
		finally{
			try{
				con.close();
				out.println("<br>connection closed");
			}
			catch(Exception e){
				e.getStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
