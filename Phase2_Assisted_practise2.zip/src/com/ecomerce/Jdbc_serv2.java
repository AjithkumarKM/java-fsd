package com.ecomerce;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Jdbc_serv2
 */
public class Jdbc_serv2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	private static final String url = "jdbc:mysql://localhost:3306/db_world";
	private static final String user = "root";
	private static final String password = "root";
	
	Connection con;
	PreparedStatement stmt;
	ResultSet rs;
	
    public Jdbc_serv2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("hello");
		
		String query="Select * from product";
		try{
			try{
				out.println("trying");
				Class.forName("com.mysql.jdbc.Driver");
			}
			catch(ClassNotFoundException e){
				e.getStackTrace();
			}
			con = DriverManager.getConnection(url,user,password);
			out.println("<br>connection established");
			
			stmt = con.prepareStatement(query);
			
			rs = stmt.executeQuery();
			
			while(rs.next()){
				int id = rs.getInt(1);
				String name =  rs.getString(2);
				double price = rs.getDouble(3);
				out.println("<br>" + id + " " + name + " " + price);
			}
		}
		catch(Exception e){
			e.getStackTrace();
		}
		finally{
			try{
				con.close();
				rs.close();
				stmt.close();
				out.println("<br>connection closed");
			}
			catch(Exception e){
				e.getStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
