package com.ecommerce.tests;

public class MyUtils {

	public int add(int n1, int n2) {
		return n1+n2;
	}
}