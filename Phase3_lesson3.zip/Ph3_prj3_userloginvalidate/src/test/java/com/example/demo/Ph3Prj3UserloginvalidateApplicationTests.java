package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ph3Prj3UserloginvalidateApplicationTests {

	@Test
	void contextLoads() {
	}
	
	@Autowired
	Validation validation;
	
	@Nested
	@DisplayName("Empty Credentials check")
	class Empty {
		@Test
		public void checkPassEmpty() {
			assertTrue(validation.checkPassEmpty(""));
		}
		
		@Test
		public void checkPassNotEmpty() {
			assertFalse(validation.checkPassEmpty("ajith"));
		}
		
		@Test
		public void checkEmailEmpty() {
			assertTrue(validation.checkEmailEmpty(""));
		}
		
		@Test
		public void checkEmailNotEmpty() {
			assertFalse(validation.checkEmailEmpty("ajith@gmail.com"));
		}
	}
	
	@Nested
	class ValidatePattern{
		@Test
		public void checkEmailPattern() {
			assertTrue(validation.checkEmailPattern("ajith@gmail.com"));
			assertFalse(validation.checkEmailPattern("ajith@"));
			assertFalse(validation.checkEmailPattern(""));
		}
		
		@Test
		public void checkPassStrength() {
			assertTrue(validation.checkPassLen("ajithkumar"));
			assertFalse(validation.checkPassLen("ajith"));
		}
	}
	
	@Nested
	class ValidateCredentials{
		@Test
		public void checkEmail() {
			assertTrue(validation.checkEmail("ajith@gmail.com"));
			assertFalse(validation.checkEmail("ajith@"));
			assertFalse(validation.checkEmail(""));
		}
		
		@Test
		public void checkPass() {
			assertTrue(validation.checkPass("ajithkumar"));
			assertFalse(validation.checkPass("ajith"));
			assertFalse(validation.checkPass(""));
		}
	}
	
	@Nested
	class Total{
		@Test
		public void testCredentials() {
			assertEquals("logged in",validation.checkLogin("ajith@gmail.com", "ajithkumar"));
			assertEquals("Error,Try again!",validation.checkLogin("ajith@gmail", "ajithkumar"));
			assertEquals("Error,Try again!",validation.checkLogin("ajith@gmail.com", "ajith"));
			assertEquals("Error,Try again!",validation.checkLogin("", ""));
			
		}
	}
}
