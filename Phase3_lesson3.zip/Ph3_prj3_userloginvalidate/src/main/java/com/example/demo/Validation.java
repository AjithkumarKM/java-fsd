package com.example.demo;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

@Component
public class Validation {

	public int validate(String email,String password) {
		if(!checkEmailEmpty(email) && !checkPassEmpty(password) && checkEmailPattern(email) &&
				checkPassLen(password) && checkEmail(email) && checkPass(password))
			return 1;
		return 0;
	}

	public boolean checkEmail(String email) {
		if(email.equals("ajith@gmail.com")) {
			return true;
		}
		return false;
	}

	public boolean checkPass(String password) {
		if(password.equals("ajithkumar"))
			return true;
		return false;
	}

	public boolean checkPassLen(String password) {
		if(password.length()>8)
				return true;
		return false;
	}

	public boolean checkEmailPattern(String email) {
		String regex = "^[A-Za-z0-9+_.-]+@(.+)$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(email);
		return matcher.matches();
	}

	public boolean checkPassEmpty(String password) {
		if(password.isEmpty())
			return true;
		return false;

	}

	public boolean checkEmailEmpty(String email) {
		if(email.isEmpty())
			return true;
		return false;
	}
	
	public String checkLogin(String email,String pass) {
		if(email.equals("ajith@gmail.com") && pass.equals("ajithkumar"))
			return "logged in";
		return "Error,Try again!";
	}
}
