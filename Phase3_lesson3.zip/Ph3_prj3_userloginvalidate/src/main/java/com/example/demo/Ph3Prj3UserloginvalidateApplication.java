package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ph3Prj3UserloginvalidateApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ph3Prj3UserloginvalidateApplication.class, args);
	}

}
