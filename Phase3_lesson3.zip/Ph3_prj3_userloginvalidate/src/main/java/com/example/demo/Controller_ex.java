package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Controller_ex {

	@Autowired
	Validation validation;
	
	@RequestMapping("home")
	public String loginPage(Model model) {
		//System.out.println("hello from home");
		model.addAttribute("user", new User());
		return "login";
	}
	
	@PostMapping("login")
	public String welcome(Model model,@ModelAttribute("user") User user) {
		if(validation.validate(user.getEmail(),user.getPassword())==1) {
			return "success";
		}
		else {
			return "error";
		}
	}
}
