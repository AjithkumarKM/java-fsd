package com.example.demo;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class KafkaSubscriber {

	@KafkaListener(topics = "topic1",groupId = "grp1")
	public void consumeMessage(String msg) {
		System.out.println("grp1 : Consumed msg" + msg);
	}
	
	@KafkaListener(topics = "topic1",groupId = "grp2")
	public void consumeMessage1(String msg) {
		System.out.println("grp2 : Consumed msg" + msg);
	}
}
