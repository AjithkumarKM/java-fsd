package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class KafkaPublisher {

	@Autowired
	KafkaTemplate<String,String> kafkaTemplate;
	
	String topic = "topic1";
	
	public void publish(String msg) {
		kafkaTemplate.send(topic,msg);
	}
}
