package com.example.demo;

public class ProductNotFoundException extends RuntimeException{

	ProductNotFoundException(){
		super("Product not found");
	}
}
