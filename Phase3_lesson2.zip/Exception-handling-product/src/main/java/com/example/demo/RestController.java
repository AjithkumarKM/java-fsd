package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@org.springframework.web.bind.annotation.RestController
public class RestController {

	@GetMapping("/{id}")
	public String product(@PathVariable("id") String id) {
		if(id.equals("0")) {
			throw new ProductNotFoundException();
		}
		return "product found";
	}
}
