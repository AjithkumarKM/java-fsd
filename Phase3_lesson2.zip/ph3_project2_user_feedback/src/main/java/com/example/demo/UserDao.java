package com.example.demo;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class UserDao {

	@Autowired
	EntityManager em;
	
	public void addFeedback(User user) {
		em.persist(user);
	}
	
	public List<User> listFeedback() {
		return em.createQuery("select u from User u", User.class).getResultList();
	}
}
