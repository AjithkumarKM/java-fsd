package com.example.demo;

import java.net.http.HttpRequest;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class User_controller {

	@Autowired
	UserDao userDao;
	
	@RequestMapping(value="/user/feedback", method=RequestMethod.POST,consumes = "application/json")
	public String addFb(@RequestBody User user) {
		userDao.addFeedback(user);
		return "Feedback added successfully";
	}

//	@RequestMapping(value="/user/feedback", method=RequestMethod.POST)
//	public String addFb(HttpServletRequest request) {
//		int id = Integer.parseInt(request.getParameter("id"));
//		String name = request.getParameter("id");
//		String feedback = request.getParameter("id");
//		User user = new User();
//		user.setId(id);
//		user.setName(name);
//		user.setFeedback(feedback);
//		userDao.addFeedback(user);
//		return "Feedback added successfully";
//	}
	
	
	@GetMapping("/user/getfeedback")
	public List<User> listFb() {
		List<User> feedback = userDao.listFeedback();
		return feedback;
	}
	
	@GetMapping("/")
	public String check() {
		return "Ok";
	}
}
