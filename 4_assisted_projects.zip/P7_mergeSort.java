package assisted_programs4;

import java.util.Scanner;

public class P7_mergeSort {

	static void merge(int[] arr,int start,int mid, int end){
		//create dup array as same length as arr
		int arr2[] = new int[arr.length];

		int i,j,k;
		i = start;
		j = mid+1;
		k = 0;
		
		while(i<=mid && j<=end){
			if(arr[i]<arr[j]){
				arr2[k] = arr[i];
				i++;
				k++;
			}
			else{
				arr2[k] = arr[j];
				j++;
				k++;
			}
		}
		
		while(i<=mid){
			arr2[k] = arr[i];
			i++;
			k++;
		}
		while(j<=end){
			arr2[k] = arr[j];
			j++;
			k++;
		}
		
		k = 0;
		for(int x=start;x<=end;x++){
			arr[x] = arr2[k++];
		}
	}
	
	static void mergeSort(int[] arr,int start,int end){
		if(start<end){
			int mid = (start+end)/2;
			mergeSort(arr,start,mid);
			mergeSort(arr,mid+1,end);
			merge(arr,start,mid,end);
		}
	}
	
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no. of elements");
		int n = sc.nextInt();
		
		int[] arr = new int[n];
		System.out.println("Enter elements");
		for(int i=0;i<n;i++){
			arr[i] = sc.nextInt();
		}
		
		mergeSort(arr,0,n-1);
		//Display sorted list
		System.out.println("Sorted array : ");
		for(int i=0;i<n;i++){
			System.out.println(arr[i] + " ");
		}
	}
}
