package assisted_programs4;

import java.util.Scanner;

public class P1_linearsearch {

	public static void main(String args[]){
		int arr[] = {12,19,4,7,62,27,45,8};
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number to search");
		int n = sc.nextInt();
		
		boolean check = false;
		for(int i=0;i<arr.length;i++){
			if(arr[i] == n){
				check = true;
				System.out.println("Element is present in the array");
				break;
			}
		}
		if(check == false){
			System.out.println("Element is not present in the array");
		}
	}
}
