package assisted_programs4;

import java.util.Scanner;

//Exponential search
public class P3_empSearch {

	static int ExpSearch(int[] arr, int key){
		if(arr[0] == key)
			return 0;
		
		int exp = 1;
		//exp => 1,2,4,8,16
		while(exp<arr.length && arr[exp]<=key){
			exp = exp*2;
		}
		return P2_binarysearch.BinarySearch(arr,exp/2,Math.min(arr.length-1,exp),key);
	}
	
	public static void main(String args[]){
		int arr[] = {4,7,8,12,14,21,23,42};
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number to search");
		int n = sc.nextInt();
		
		int index = ExpSearch(arr,n);
		if(index != -1){
			System.out.println("Element is present in the array at index " + index);
		}
		else{
			System.out.println("Element is not present in the array");
		}
	}
}
