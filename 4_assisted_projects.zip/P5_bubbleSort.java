package assisted_programs4;

import java.util.Scanner;

public class P5_bubbleSort {

	static void bubbleSort(int[] arr,int n){
		
		//large elem will pop out and put at end for each loop
		int temp;
		for(int i=0;i<n;i++){
			//j < n-i-1 -> comparing next elem & already sorted last i elem
			for(int j=i;j<n-i-1;j++){
				if(arr[j]>arr[j+1]){
					temp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp;
				}
			}
		}
	}
	
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no. of elements");
		int n = sc.nextInt();
		
		int[] arr = new int[n];
		System.out.println("Enter elements");
		for(int i=0;i<n;i++){
			arr[i] = sc.nextInt();
		}
		
		bubbleSort(arr,n);
		
		//Display sorted list
		System.out.println("Sorted array : ");
		for(int i=0;i<n;i++){
			System.out.println(arr[i] + " ");
		}
		
	}
}
