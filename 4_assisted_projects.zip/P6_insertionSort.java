package assisted_programs4;

import java.util.Scanner;

public class P6_insertionSort {

	static void insertionSort(int[] arr,int n){
		
		int j,temp;
		for(int i=1;i<n;i++){
			j = i;
			//comp with prev elem if it is large swap else move next prev elem
			//index should be greater than 0
			while(j>0 && arr[j-1]>arr[j] ){
				temp = arr[j-1];
				arr[j-1] = arr[j];
				arr[j] = temp;
				j--;
			}
		}
	}
	
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no. of elements");
		int n = sc.nextInt();
		
		int[] arr = new int[n];
		System.out.println("Enter elements");
		for(int i=0;i<n;i++){
			arr[i] = sc.nextInt();
		}
		
		insertionSort(arr,n);
		//Display sorted list
		System.out.println("Sorted array : ");
		for(int i=0;i<n;i++){
			System.out.println(arr[i] + " ");
		}
	}
}
