package assisted_programs4;

import java.util.Scanner;

public class P4_selectionsort {

	static int nextMin(int[] arr,int i,int len){
		int minVal = arr[i];
		int minIndex = i;
		for(int j=i+1;j<len;j++){
			if(arr[j]<minVal){
				minVal = arr[j];
				minIndex = j;
			}
		}
		return minIndex;
	}
	
	static void SelectionSort(int[] arr,int len){
		//find min elem afterwards and put it at i and repeat from i+1
		for(int i=0;i<len;i++){
			int index = nextMin(arr,i,len);
			
			//swapping ith and min element
			int temp = arr[i];
			arr[i] = arr[index];
			arr[index] = temp;
		}
	}
	
	public static void main(String args[]){
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no. of elements");
		int n = sc.nextInt();
		
		int[] arr = new int[n];
		System.out.println("Enter elements");
		for(int i=0;i<n;i++){
			arr[i] = sc.nextInt();
		}
		
		SelectionSort(arr,n);
		
		System.out.println("Sorted array : ");
		for(int i=0;i<n;i++){
			System.out.println(arr[i] + " ");
		}
		
	}
}
