package assisted_programs4;

import java.util.Scanner;

public class P8_mergeSort {

	static int getPivot(int[] arr,int start,int end){

		int pivot = arr[end];
		int i = start;
		int temp;
		
		// start from start index, if elem is LsT pivot swap with i

		for(int j=start;j<end;j++){
			if(arr[j]<pivot){
				temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
				i++;
			}
		}
		// eventually i will be in index of elem LrT than pivot swap it and return
		temp = arr[i];
		arr[i] = arr[end];
		arr[end] = temp;
		
		return i;
	}
	
	static void quickSort(int[] arr,int start, int end){
		if(start<end){
			int pivot = getPivot(arr,start,end);
			quickSort(arr,start,pivot-1);
			quickSort(arr,pivot+1,end);
		}
	}
	
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no. of elements");
		int n = sc.nextInt();
		
		int[] arr = new int[n];
		System.out.println("Enter elements");
		for(int i=0;i<n;i++){
			arr[i] = sc.nextInt();
		}
		
		quickSort(arr,0,n-1);
		//Display sorted list
		System.out.println("Sorted array : ");
		for(int i=0;i<n;i++){
			System.out.println(arr[i] + " ");
		}
	}
}
