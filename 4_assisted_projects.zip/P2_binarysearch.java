package assisted_programs4;

import java.util.Scanner;

public class P2_binarysearch {

	static int BinarySearch(int[] arr, int start, int end, int n){
		
		if(end>=start){
			
			//int mid = start +(end-start)/2 ;
			int mid = (start+end)/2 ;
			
			//System.out.println("m : " + mid);
			if(arr[mid] == n){
				return mid;
			}
			else if(arr[mid]<n){
				return BinarySearch(arr,mid+1,end,n);
			}
			else{
				return BinarySearch(arr,start,mid-1,n);
			}
		}
		return -1;
	}
	public static void main(String args[]){
		int arr[] = {4,7,8,12,17,21,23,42};
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number to search");
		int n = sc.nextInt();
		
		int check = BinarySearch(arr,0,arr.length-1,n);
		if(check != -1){
			System.out.println("Element is present in the array at index " + check);
		}
		else{
			System.out.println("Element is not present in the array");
		}
	}
}
