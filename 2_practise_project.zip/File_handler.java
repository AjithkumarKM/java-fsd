package projects;

import java.io.*;
import java.util.*;

public class File_handler {

	public static void main(String args[]){
		
		String path = "D://JAVA//exercise//newfile.txt";
		try{
			FileReader fr = new FileReader(path);
			BufferedReader br = new BufferedReader(fr);
			String s = "";
			while((s=br.readLine())!=null){
				System.out.println(s);
			}
			br.close();
			fr.close();
		}
		catch(FileNotFoundException e){
			System.out.println(e.getStackTrace());
		}
		catch(IOException e){
			System.out.println(e.getStackTrace());			
		}
		catch(Exception e){
			System.out.println(e.getStackTrace());			
		}
		
		Scanner sc = new Scanner(System.in);
		System.out.println("\nEnter string  to write in the file:");
		String s = sc.nextLine();
		try{
			FileWriter fw = new FileWriter(path);
			s += System.lineSeparator(); 
			fw.write(s);
			fw.close();
			System.out.println("Data is written successfully");
		}
		catch(FileNotFoundException e){
			System.out.println(e.getStackTrace());
		}
		catch(Exception e){
			System.out.println(e.getStackTrace());			
		}
		
		System.out.println("\nEnter string  to append in the file:");
		String s1 = sc.nextLine();
		try{
			FileWriter fw = new FileWriter(path,true);
			s1 += System.lineSeparator(); 
			fw.write(s1);
			fw.close();
			System.out.println("Data is appended successfully");
		}
		catch(FileNotFoundException e){
			System.out.println(e.getStackTrace());
		}
		catch(Exception e){
			System.out.println(e.getStackTrace());			
		}
	}
}
