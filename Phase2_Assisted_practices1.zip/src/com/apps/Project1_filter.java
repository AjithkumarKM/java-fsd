package com.apps;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Servlet Filter implementation class Project1_filter
 */
public class Project1_filter implements Filter {

    /**
     * Default constructor. 
     */
    public Project1_filter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		String login_email = "ajithkumar@gmail.com";
		String login_password = "thjia";
		if(!email.equals(login_email)){
			response.getWriter().write("Invalid email!! Try again");
		}
		else if(!password.equals(login_password)){
			response.getWriter().write("Invalid Password!! Try again");
		}
		else if(email.equals(login_email) && password.equals(login_password)){
			chain.doFilter(request, response);
		}
		else{
			response.getWriter().write("Invalid credentials!! Try again");
		}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
