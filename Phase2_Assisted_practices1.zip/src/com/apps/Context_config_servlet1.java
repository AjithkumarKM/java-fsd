package com.apps;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Context_config_servlet1
 */
public class Context_config_servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Context_config_servlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());

    	PrintWriter pw=response.getWriter();
    	response.setContentType("text/html");

		ServletConfig conf=getServletConfig();  // Step 1: instantiate ServeltConfig

		String s1=conf.getInitParameter("n1");   //Step 2: fetching the parameters from the web.xml
		Integer a = Integer.parseInt(s1);
		String s2=conf.getInitParameter("n2");
		Integer b = Integer.parseInt(s2);
		String s3=conf.getInitParameter("n3");
		Integer c = Integer.parseInt(s3);

		ServletContext context = getServletContext();
		String s4=context.getInitParameter("n4");
		Integer d = Integer.parseInt(s4);		
		
		pw.println("n1 value is " +s1+ " and n2 is " +s2+ " and n3 is " +s3 + " and n4 is " +s4);
		pw.println("\ntotal is " + (a+b+c+d));
		
		pw.println("\nServlet Name" + conf.getServletName());
		pw.println("\nServlet context" + conf.getServletContext());
		
	   pw.close();	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
