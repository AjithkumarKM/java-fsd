package com.apps;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Servlet implementation class Servlet_interface
 */
public class Servlet_interface implements Servlet {

	ServletConfig config = null;
	@Override
	public void destroy() {
		System.out.println("Servlet destroyed");
	}

	@Override
	public ServletConfig getServletConfig() {
		return config;
	}

	@Override
	public String getServletInfo() {
		return "returning from servlet info method";
	}

	@Override
	public void init(ServletConfig arg0) throws ServletException {
		this.config = config;
		System.out.println("Init method");
	}

	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
        PrintWriter pwriter=response.getWriter();
        pwriter.print("<html>");
        pwriter.print("<body>");
        pwriter.print("In the service() method<br>");
        pwriter.print("</body>");
        pwriter.print("</html>");
		
	}
	

}
