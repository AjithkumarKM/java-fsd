package com.example.demo.quiz;

import org.springframework.data.repository.CrudRepository;

public interface QuizRepo extends CrudRepository<Quiz, Integer>{

}
