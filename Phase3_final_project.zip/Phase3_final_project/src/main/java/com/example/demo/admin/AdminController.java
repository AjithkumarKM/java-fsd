package com.example.demo.admin;

import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.questions.Question;
import com.example.demo.questions.QuestionService;
import com.example.demo.quiz.Quiz;
import com.example.demo.quiz.QuizService;
import com.example.demo.users.TestDetails;
import com.example.demo.users.TestDetailsService;
import com.example.demo.users.Users;
import com.example.demo.users.UsersService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	AdminService adminService;
	
	@Autowired
	private TestDetailsService testDetailsService;
	
	@Autowired
	private QuizService quizService;
	
	@Autowired
	private QuestionService questionService;
	
	@Autowired
	private UsersService usersService;
	
	@PostMapping("/addAdmin")
	public Admin addAdmin(@RequestBody Admin admin) {
		return adminService.addAdmin(admin);
	}
	
	@GetMapping("/getAllAdmin")
	public List<Admin> getAllAdmin(){
		return adminService.getAllAdmin();
	}
	
	@PutMapping("/updatePassword")
	public Admin updatePassword(@RequestParam("id") String id,@RequestParam("password") String password) {
		int sid = Integer.parseInt(id);
		System.out.println(sid);
		System.out.println(id + " " + password);
		return adminService.updatePassword(sid,password);
	}
	
	@GetMapping("/login")
	public String loginAdmin(@RequestBody Admin admin) {
		if(adminService.findAdmin(admin))
			return "login successful";
		else
			return "Try again";
	}
	
	@GetMapping("/getTestDetails")
	public List<TestDetails> getAllTestDetails(){
		//http://localhost:8080/admin/getTestDetails
		return testDetailsService.getAllTestDetails();
	}
	
	@GetMapping("/getAllQuiz")
	public List<Quiz> getAllQuiz(){
		return quizService.getAllQuiz();
	}
	
	@GetMapping("/getAllQuestion")
	public List<Question> getAllQn(){
		return questionService.getAllQn();
	}
	
	@GetMapping("/getAllUsers")
	public List<Users> getAllUsers(){
		return usersService.getAllUser();
	}

	@GetMapping("/testStatistics/{quizid}")
	public SortedMap<Integer, Integer> getStatistics(@PathVariable String quizid){
		List<TestDetails> details = testDetailsService.getTestDetailForQuiz(quizid);
		SortedMap<Integer,Integer> score = new TreeMap<Integer, Integer>();
		for(TestDetails i: details) {
			score.put(i.getUsers().getUserid(), i.getScore());
		}
		return score;
	}
	
	@PostMapping("/addQn")
	public Question addQn(@RequestBody Question question) {
		return questionService.addQn(question);
	}
	
	@PostMapping("/addQuiz")
	public Quiz addQuiz(@RequestBody Quiz quiz) {
		return quizService.addQuiz(quiz);
	}
	
	@PostMapping("/addQnToQuiz")
	public String addQn(@RequestParam String[] questions,@RequestParam String quizid){
		//http://localhost:8080/quiz/addQn?questions=1,2&quizid=1
		return questionService.addQuizId(questions,quizid);
	}
}
