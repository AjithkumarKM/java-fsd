package com.example.demo.users;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UsersService {

	@Autowired
	private UsersRepo usersRepo;
	
	public List<Users> getAllUser(){
		System.out.println(usersRepo.findAll());
		return (List<Users>) usersRepo.findAll();
	}
	
	public Users addUser(Users user) {
		return usersRepo.save(user);
	}
	
	public Users getUserById(String id) {
		int userid = Integer.parseInt(id);
		return usersRepo.findById(userid).orElse(null);
	}
	
}
