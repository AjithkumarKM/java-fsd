package com.example.demo.quiz;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.example.demo.questions.Question;
import com.example.demo.users.TestDetails;

@Entity
@Table(name="quiz")
public class Quiz {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="quiz_id")
	private int quiz_id;
	
	@Column(name="quiz_name")
	private String quiz_name;

//	@OneToMany(cascade = CascadeType.ALL)
//	@JoinColumn(name = "id", nullable = false)
//	private Set<Question> question;

//	@OneToMany(mappedBy="quiz")
//	private Set<TestDetails> testdetails;
	
	public int getId() {
		return quiz_id;
	}

	public void setId(int id) {
		this.quiz_id = id;
	}

	public String getQuiz_name() {
		return quiz_name;
	}

	public void setQuiz_name(String quiz_name) {
		this.quiz_name = quiz_name;
	}

	@Override
	public String toString() {
		return "Quiz [id=" + quiz_id + ", quiz_name=" + quiz_name ;
	}
	
	public Quiz(String quiz_name) {
		super();
		this.quiz_name = quiz_name;
		//this.question = question;
	}

//	public Set<Question> getQuestion() {
//		return question;
//	}
//
//	public void setQuestion(Set<Question> question) {
//		this.question = question;
//	}
	

	public Quiz() {
		super();
	}

//	public Set<TestDetails> getTestdetails() {
//		return testdetails;
//	}
//
//	public void setTestdetails(Set<TestDetails> testdetails) {
//		this.testdetails = testdetails;
//	}
	
}
