package com.example.demo.admin;

import java.util.List;

import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminService {

	@Autowired
	private AdminRepo adminRepo;
	
	public Admin addAdmin(Admin admin) {
		return adminRepo.save(admin);
	}
	
	public List<Admin> getAllAdmin(){
		return (List<Admin>) adminRepo.findAll();
	}
	
	public Admin updatePassword(int id,String password) {
		Admin admin = adminRepo.findById(id).get();
		admin.setPassword(password);
		return adminRepo.save(admin);
	}
	
	public boolean findAdmin(Admin admin) {
		
		Admin ladmin = adminRepo.findById(admin.getId()).get();
		System.out.println(ladmin.getName()+" " + ladmin.getPassword());
		if(ladmin.getName().equalsIgnoreCase(admin.getName()) && ladmin.getPassword().equalsIgnoreCase(admin.getPassword()))
			return true;
		return false;
	}
}
