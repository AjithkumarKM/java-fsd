package com.example.demo.quiz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class QuizService {

	@Autowired
	private QuizRepo quizRepo;
	
	public Quiz addQuiz(Quiz quiz) {
		return quizRepo.save(quiz); 
	}
	
	public List<Quiz> getAllQuiz() {
		return (List<Quiz>) quizRepo.findAll(); 
	}
	
	public Quiz getQuizById(int quizid) {
		return quizRepo.findById(quizid).get(); 
	}
	
	
}
