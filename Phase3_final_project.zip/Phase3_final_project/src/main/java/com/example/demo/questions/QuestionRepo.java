package com.example.demo.questions;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface QuestionRepo extends CrudRepository<Question, Integer>{

	@Query("select new Question(qnid,question,choice1,choice2,choice3,choice4) from Question where quiz_id=:qid")
	//@Query("from Question where quiz_id=:qid")
	//public List<Question> findAllByQuizId(@Param("qid") int quizid);
	public List<Question> findAllByQuizId(@Param("qid") int quizid);
	
	@Query("select qnid,question,answer from Question where quiz_id=:qid")	
	public List<Object> getAnswers(@Param("qid") int quizid);
}
