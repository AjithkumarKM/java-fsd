package com.example.demo.answers;
/*
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import com.example.demo.questions.Question;

@Entity
@Table(name="answers")
@Component
public class Answers {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="answerid")
	private int answerid;
	
	@Column(name="answer")
	private String answer;

	public int getAnswerid() {
		return answerid;
	}

	public void setAnswerid(int answerid) {
		this.answerid = answerid;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public Answers(String answer) {
		super();
		this.answer = answer;
	}
	
	public Answers() {
	}

	@Override
	public String toString() {
		return "Answers [answerid=" + answerid + ", answer=" + answer + "]";
	}
	
	
}
*/