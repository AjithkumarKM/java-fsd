package com.example.demo.admin;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AdminRepo extends CrudRepository<Admin, Integer>{

	//@Query("from Admin a where a.name=:name and a.password=:password")
	//public Admin findAdmin(@Param("name") String name,@Param("password") String password);
	
}
