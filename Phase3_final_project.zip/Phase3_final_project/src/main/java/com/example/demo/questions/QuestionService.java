package com.example.demo.questions;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.quiz.Quiz;
import com.example.demo.quiz.QuizRepo;

@Service
public class QuestionService {

	@Autowired
	private QuestionRepo questionRepo;
	
	@Autowired
	private QuizRepo quizRepo;
	
	public Question addQn(Question question) {
		return questionRepo.save(question);
	}
	
	public List<Question> getAllQn() {
		System.out.println(questionRepo.findAll());
		return (List<Question>) questionRepo.findAll();
	}
	
	public String addQuizId(String[] questions,String quizid){
		int qzid = Integer.parseInt(quizid);
		Quiz quiz = quizRepo.findById(qzid).orElse(null);
		if(quiz==null) {
			System.out.println("quiz id not found");
			return "quiz id not found";
		}
		for(String i:questions) {
			int qnid = Integer.parseInt(i);
			Question qn = questionRepo.findById(qnid).orElse(null);
			if(qn==null) {
				System.out.println("question id not found " + qnid);
			}
			qn.setQuiz(quiz);
			questionRepo.save(qn);
		}
		return "questions added to quiz";
	}
	
	public List<Question> getByQuizId(String quizid){
		int qzid = Integer.parseInt(quizid);
		System.out.println(questionRepo.findAllByQuizId(qzid));
		return questionRepo.findAllByQuizId(qzid);
	}
	
	public Question getQnById(int qnId) {
		//int qid = Integer.parseInt(qnId);
		return questionRepo.findById(qnId).orElse(null);
	}
	
	public List<Object> getAnswers(String quizid){
		int qzid = Integer.parseInt(quizid);
		return questionRepo.getAnswers(qzid);
	}
}
