package com.example.demo.users;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.example.demo.quiz.Quiz;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name="testdetails")
public class TestDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="testid")
	private int testid;
	
	//@Column(name="userid")
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="userid")
	private Users users;
	
	//@Column(name="quizid")
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="quizid")
	private Quiz quiz;
	
	@Column(name="score")
	private int score;

	public int getTestid() {
		return testid;
	}

	public void setTestid(int testid) {
		this.testid = testid;
	}

	public Users getUsers() {
		return users;
	}

	public void setUsers(Users users) {
		this.users = users;
	}

	public Quiz getQuiz() {
		return quiz;
	}

	public void setQuiz(Quiz quiz) {
		this.quiz = quiz;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public TestDetails() {
	}

	public TestDetails(Users users, Quiz quiz, int score) {
		super();
		this.users = users;
		this.quiz = quiz;
		this.score = score;
	}

	@Override
	public String toString() {
		return "TestDetails [testid=" + testid + ", users=" + users + ", quiz=" + quiz + ", score=" + score + "]";
	}
	
}
