package com.example.demo.users;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.quiz.Quiz;

@Repository
public interface TestDetailsRepo extends CrudRepository<TestDetails, Integer>{

//	@Query("select distinct t from TestDetails t join t.users u join t.quiz where u.userid=:uid")
//	public TestDetails getResult(@Param("uid") int uid);
//	//SELECT DISTINCT o FROM Order o JOIN o.orderDetails od JOIN od.product p"
//    //+ " WHERE p.name LIKE %?1%
////	//INNER JOIN Area a ON a.idUser = u.idUser
////	//public TestDetails getResult();

	 @Query(value="select * from testdetails where userid=:uid", nativeQuery=true)
	 public List<TestDetails> getResult(@Param("uid") int uid);
	 
	 @Query(value="select * from testdetails where quizid=:qid", nativeQuery=true)
	 public List<TestDetails> getQuizResult(@Param("qid") int qid);
}
