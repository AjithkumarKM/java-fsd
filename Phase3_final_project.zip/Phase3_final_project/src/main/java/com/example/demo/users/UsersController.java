package com.example.demo.users;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.questions.Question;
import com.example.demo.questions.QuestionService;
import com.example.demo.quiz.Quiz;
import com.example.demo.quiz.QuizService;

@RestController
@RequestMapping("/user")
public class UsersController {

	@Autowired
	private UsersService usersService;
	
	@Autowired
	private QuizService quizService;
	
	@Autowired
	private QuestionService questionService;
	
	@Autowired
	private TestDetailsService testDetailsService;
	
	@PostMapping("/addUser")
	public Users addUser(@RequestBody Users user) {
		return usersService.addUser(user);
	}
	
	@GetMapping("/getAllUsers")
	public List<Users> getAllUsers(){
		return usersService.getAllUser();
	}
	
	@GetMapping("/getAllQuiz")
	public List<Quiz> getAllQuiz(){
		return quizService.getAllQuiz();
	}
	
	@GetMapping("/getQuizById")
	public Quiz getQuizById(@RequestParam String quizId){
		int qid = Integer.parseInt(quizId);
		return quizService.getQuizById(qid);
	}
	
	@GetMapping("/takeQuiz/{quizid}")
	public List<Question> takeQuiz(@PathVariable("quizid") String quizid){
		//System.out.println("Quiz id " + quizid);
		//http://localhost:8080/user/takeQuiz/1
		return questionService.getByQuizId(quizid);
	}
	
	@PostMapping("/postAnswer/{quizid}/{userid}")
	public String postAnswers(@RequestBody List<Question> answers,@PathVariable("quizid") String quizid,
			@PathVariable("userid") String userid){
		//http://localhost:8080/user/postAnswer/1/1
		//http://localhost:8080/user/postAnswer/1/2
		int score=0;
		for(Question i: answers) {
			Question question = questionService.getQnById(i.getQnid());
			if(question.getAnswer().equalsIgnoreCase(i.getAnswer()))
				score +=1;
		}
		testDetailsService.addTestDetail(quizid, userid, score);
		return "Quiz submitted successfully";
	}
	
	@GetMapping("/getAnswers/{quizid}")
	public List<Object> getAnswers(@PathVariable("quizid") String quizid){
		return questionService.getAnswers(quizid);
	}
	
	@GetMapping("/getScore/{quizid}/{userid}")
	public List<TestDetails> getScore(@PathVariable String quizid, @PathVariable String userid) {
		//http://localhost:8080/user/getScore/1/1
		List<TestDetails> details = testDetailsService.getTestDetail(quizid, userid);
		return details;
	}
	
	@GetMapping("/getPosition/{quizid}/{userid}")
	public int getPosition(@PathVariable String quizid, @PathVariable String userid) {
		//http://localhost:8080/user/getPosition/1/1
		List<TestDetails> details = testDetailsService.getTestDetailForQuiz(quizid);
		SortedMap<Integer,Integer> score = new TreeMap<Integer, Integer>();
		for(TestDetails i: details) {
			score.put(i.getUsers().getUserid(), i.getScore());
		}
//		SortedSet ts = (SortedSet) score.entrySet();
//		Iterator itr = ts.iterator();
//		int userScore = score.get(userid);
//		int j=0;
//		while(itr.hasNext()) {
//			 Map.Entry m = (Map.Entry)itr.next(); 
//	         int userid1 = (Integer)m.getKey();
//	         Integer score1 = (Integer)m.getValue();
//		}
		
		int size = score.size();
		int j=size;
		int uid = Integer.parseInt(userid);
		for (SortedMap.Entry<Integer,Integer> entry : score.entrySet()) 
		{
			if(uid==entry.getKey())
			{
				break;
			}
			j--;
		}
		System.out.println(score);
		System.out.println("Position is " + j);
		return j;
	}
}
