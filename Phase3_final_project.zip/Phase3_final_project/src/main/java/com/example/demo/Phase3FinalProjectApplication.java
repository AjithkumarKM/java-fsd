package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.admin.Admin;
import com.example.demo.admin.AdminService;
//import com.example.demo.answers.Answers;
import com.example.demo.questions.Question;
import com.example.demo.questions.QuestionService;
import com.example.demo.quiz.Quiz;
import com.example.demo.quiz.QuizService;
import com.example.demo.users.Users;
import com.example.demo.users.UsersService;

@SpringBootApplication
public class Phase3FinalProjectApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(Phase3FinalProjectApplication.class, args);
	}

	@Autowired
	private QuestionService questionService;
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private QuizService quizService;
	
	@Autowired
	private UsersService usersService;
	
	@Override
	public void run(String... args) throws Exception {
		questionService.addQn(new Question("Which is top backend platform?","CSS","HTML","JS","Spring","Spring"));
		questionService.addQn(new Question("Which mobile r u using?","Moto","Mi","Iphone","Vivo","Moto"));
		//questionService.addQn(new Question("Select the correct result 1+2?","4","3","5","6","3"));
		//questionService.addQn(new Question("which is electronic gadget?","wood","leaves","fan","sand","fan"));

		//questionService.getQn();
		adminService.addAdmin(new Admin("admin1","admin123#"));
		adminService.addAdmin(new Admin("admin2","admin@456"));
		adminService.addAdmin(new Admin("admin3","hello@123"));
		quizService.addQuiz(new Quiz("General quiz"));
		//quizService.addQuiz(new Quiz("Maths quiz"));
		usersService.addUser(new Users("ajith","ajith@gmail.com",8076543218L));
		usersService.addUser(new Users("kavi","kavi@gmail.com",8077865432L));
		//usersService.addUser(new Users("mari","mari@gmail.com",9876654345L));
	}

}
