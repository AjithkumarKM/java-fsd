package com.example.demo.users;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.quiz.Quiz;
import com.example.demo.quiz.QuizService;

@Service
public class TestDetailsService {

	@Autowired
	private TestDetailsRepo testDetailsRepo;
	
	@Autowired
	private UsersService usersService;
	
	@Autowired
	private QuizService quizService;
	
	public TestDetails addTestDetail(String quizid,String userid,int score) {
		int qzid = Integer.parseInt(quizid);
		Quiz quiz = quizService.getQuizById(qzid);
		Users user = usersService.getUserById(userid);
		return testDetailsRepo.save(new TestDetails(user,quiz,score));
	}
	
	public List<TestDetails> getTestDetail(String quizid,String userid) {
		int qzid = Integer.parseInt(quizid);
		int uid = Integer.parseInt(userid);
		//Quiz quiz = quizService.getQuizById(qzid);
		//Users user = usersService.getUserById(userid);
		System.out.println( testDetailsRepo.getResult(uid));
		List<TestDetails> details =  testDetailsRepo.getResult(uid);
		return details;
	}
	
	public List<TestDetails> getTestDetailForQuiz(String quizid) {
		int qzid = Integer.parseInt(quizid);
		System.out.println( testDetailsRepo.getQuizResult(qzid));
		List<TestDetails> details =  testDetailsRepo.getQuizResult(qzid);
		return details;
	}
	
	public List<TestDetails> getAllTestDetails(){
		return (List<TestDetails>) testDetailsRepo.findAll();
	}
}
