package com.technicalkeeda.dao;

import com.technicalkeeda.entities.Movie;

public interface MovieDao {
	public void createMovie(Movie movie);
}