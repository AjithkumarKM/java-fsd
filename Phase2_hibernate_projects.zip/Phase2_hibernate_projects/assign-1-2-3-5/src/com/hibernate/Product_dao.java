package com.hibernate;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Product_dao {
	public static void main(String args[]){
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
        Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();  
         
       SessionFactory factory = meta.getSessionFactoryBuilder().build();  
       Session session = factory.openSession();  
       Transaction t = session.beginTransaction();  
       
       Product p = new Product();
       p.setId(4);
       p.setName("scale");
       p.setPrice(15);

//       List<Product> admin = session.createQuery("from Product").list();
//       for(Product e: admin){
//    	   System.out.println(e.getId() + " " + e.getPrice());
//       }
       session.save(p);
       
       t.commit();
	}
	
	public void insertProduct(int pid,String pname,int pprice){
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
        Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();  
         
       SessionFactory factory = meta.getSessionFactoryBuilder().build();  
       Session session = factory.openSession();  
       Transaction t = session.beginTransaction();  
       
       Product p = new Product();
       p.setId(pid);
       p.setName(pname);
       p.setPrice(pprice);
       
       System.out.println("Product inserted");
//       List<Product> admin = session.createQuery("from Product").list();
//       for(Product e: admin){
//    	   System.out.println(e.getId() + " " + e.getPrice());
//       }
       session.save(p);
       
       t.commit();		
	}
}
