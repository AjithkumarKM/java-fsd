package assisted_programs3;

class Queue{
	static final int size = 1000;
	int front,rear;
	int[] arr = new int[size];
	
	Queue(){
		this.front = -1;
		this.rear = -1;
	}
	
	boolean isfull(){
		return (this.front==0 && this.rear==size-1);
	}
	
	boolean isEmpty(){
		return (front<0 && rear<0);
	}
	
	boolean Enqueue(int data){
		if(isfull()){
			System.out.println("Queue is full(oveflow)");
			return false;
		}
		else{
			if(front==-1)
				front = 0;
			arr[++rear] = data;
			System.out.println("Element is inserted");			
		}
		return true;
	}
	
	int Dequeue(){
		if(isEmpty()){
			System.out.println("Queue is empty(Underflow)");
			return 0;
		}
		else{
			int val = arr[front];
			if(this.front>=this.rear){
				this.front = -1;
				this.rear = -1;
			}
			front++;
			System.out.println("\nElement is dequeued");
			return val;
		}
	}
	void display(){
		System.out.println("\nDisplaying queue");
		for(int i=front;i<=rear;i++){
			System.out.print(" " + arr[i]);
		}
	}
	void peek(){
		System.out.println("\nThe peek element is " + arr[rear]);
	}
}


public class P9_queue {
	public static void main(String args[]){
		Queue q = new Queue();
		q.Enqueue(4);
		q.Enqueue(6);
		q.Enqueue(9);
		q.Enqueue(7);
		q.display();
		
		System.out.println(q.Dequeue());
		
		q.peek();
		q.display();
	}
}
