package assisted_programs3;

import java.util.Scanner;

public class P1_arrayrotation {

	static void array_rotate(int[] arr,int n,int k){
		if(k>n)
			k = k % n;
		int[] dup = new int[n];
		for(int i=0;i<k;i++){
			dup[i] = arr[n-k+i];
		}
		int j=0;
		for(int i=k;i<n;i++){
			dup[i] = arr[j];
			j++;
		}
		for(int i=0;i<n;i++){
			arr[i] = dup[i];
		}
	}
	
	public static void main(String args[]){
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no. of elements");
		int n = sc.nextInt();
		int[] arr = new int[n];
		System.out.println("Enter elements of array");
		for(int i=0;i<n;i++){
			arr[i] = sc.nextInt();
		}
		int k;
		System.out.println("Enter position to shift");
		k = sc.nextInt();
		
		array_rotate(arr,n,k);
		for(int i=0;i<n;i++){
			System.out.print(" " + arr[i]);
		}
	}
}
