package assisted_programs3;

import java.util.Scanner;

class Circularlist{
	Node head;
	static class Node{
		int data;
		Node next;
		Node(int data){
			this.data = data;
		}
	}
	
	public Circularlist insertList(Circularlist list, int data){
		Node new_node = new Node(data);
		Node temp = list.head;
		if(list.head==null){
			new_node.next = new_node;
			list.head = new_node;
		}
		else if(temp.data>=data){
			while(temp.next!=list.head){
				temp = temp.next;
			}
			temp.next = new_node;
			new_node = list.head;
			list.head = new_node;
		}
		else{
			while(temp.next!=list.head && temp.data<data){
				temp = temp.next;
			}
			new_node.next = temp.next;
			temp.next = new_node;
			
		}
		return list;
	}
	
	public void displayList(Circularlist l){
		Node n = l.head;
		int i=0;
		if(l.head==null){
			System.out.println("List is empty");
		}
		else
		{	
			System.out.println("\nDisplaying list");
			while(n.next!=l.head){
				System.out.println(i+": " + n.data);
				n = n.next;
				i++;
			}
			System.out.println(i+": " + n.data);
		}
	}
	
}

public class P6_circularlist {

	public static void main(String args[]){
		int key;
		int option;
		Scanner sc = new Scanner(System.in);
		Circularlist l =new Circularlist();
		while(true){
			System.out.println("\nEnter option ");
			option = sc.nextInt();
			if(option==1){
				System.out.println("Enter element to insert");
				key = sc.nextInt();
				l = l.insertList(l, key);
			}
			else if(option==2){
				l.displayList(l);
			}
			else{
				break;
			}
		}
	}
}
