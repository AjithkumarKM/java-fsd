package assisted_programs3;

import java.util.Scanner;

class Llist{
	Node head;
	static class Node{
		int data;
		Node next;
		Node(int data){
			this.data = data;
		}
	}
	
	public static Llist insertFirst(Llist list, int data){
		Node new_node = new Node(data);
		if(list.head==null){
			list.head = new_node;
		}
		else{
			new_node.next = list.head;
			list.head = new_node;
		}
		return list;
	}
	public static Llist insertLast(Llist list, int data){
		Node new_node = new Node(data);

		if(list.head==null){
			list.head = new_node;
		}
		else{
			Node n = list.head;
			while(n.next!=null){
				n = n.next;
			}
			n.next = new_node;
		}
		return list;
	}
	
	public void displayList(Llist l){
		Node n = l.head;
		int i=0;
		if(l.head==null){
			System.out.println("List is empty");
		}
		else
		{	
			System.out.println("\nDisplaying list");
			while(n!=null){
				System.out.println(i+": " + n.data);
				n = n.next;
				i++;
			}
		}
	}
	Llist deleteKey(Llist l,int data){
		Node currNode = l.head;

		if(currNode==null){
			System.out.println("List is empty");
			return l;
		}
		if(currNode!=null && currNode.data == data){
			l.head = currNode.next;
			return l;
		}
		Node prev = null;
		while(currNode!=null && currNode.data!=data){
			prev = currNode;
			currNode = currNode.next;
		}
		if(currNode==null){
			System.out.println(data + "is not in the list");
		}
		else{
			prev.next = currNode.next;
		}
		return l;
	}
	
}

public class P5_simglylinkedlist {

	public static void main(String args[]){
		Llist l = new Llist();
//		l = l.insertFirst(l, 4);
//		l = l.insertFirst(l, 5);
//		l = l.insertFirst(l, 3);
//		l = l.insertFirst(l, 2);
//		l = l.insertLast(l, 8);
//		l = l.insertLast(l, 9);
//		
//		l.displayList(l);
//		l = l.deleteKey(l, 5);
//		l.displayList(l);

		Scanner sc = new Scanner(System.in);
		int key;
		int option;
		System.out.println("\n1.InsertFirst 2.InsertLast 3.DeleteKey 4.Display");
		while(true){
			System.out.println("\nEnter option ");
			option = sc.nextInt();
			if(option==1){
				System.out.println("Enter element to insert");
				key = sc.nextInt();
				l = l.insertFirst(l, key);
			}
			else if(option==2){
				System.out.println("Enter element to insert");
				key = sc.nextInt();
				l = l.insertLast(l, key);
			}
			else if(option==3){
				System.out.println("Enter element to delete");
				key = sc.nextInt();
				l = l.deleteKey(l, key);
			}
			else if(option==4){
				l.displayList(l);
			}
			else{
				break;
			}
		}
	}
}
