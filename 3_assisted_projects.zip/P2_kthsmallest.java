package assisted_programs3;

import java.util.Scanner;

public class P2_kthsmallest {

	static int KthSmallest(int[] arr,int s, int n, int k){
		if(k>0 && k<=n-s+1)
			{
			int pos = partition(arr,s,n);
			//System.out.println("Pos: " + pos + " K : " + k);
			if(pos-s == k-1){
				System.out.println("arr[i] " + arr[pos]);
				//return arr[pos];
			}
			if(pos-s > k-1){
				KthSmallest(arr,s,pos-1,k);
			}
			KthSmallest(arr,pos+1,n,k-pos+s-1);
			}
		//k is largest than n return max value
			return Integer.MAX_VALUE;
	}
	
	//use sort to return index of pivot
	static int partition(int[] arr,int s, int n){
		int pivot = arr[n];
		int i = s;
		for(int j=s;j<=n-1;j++){
			if(arr[j]<=pivot){
				int temp = arr[j];
				arr[j] = arr[i];
				arr[i] = temp;
				i++;
			}
		}
		int temp = arr[n];
		arr[n] = arr[i];
		arr[i] = temp;
		
//		for(int k=s;k<n;k++){
//			System.out.println(": " + i);
//		}
		return i;
	}
	
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no. of elements");
		int n = sc.nextInt();
		int[] arr = new int[n];
		System.out.println("Enter elements of array");
		for(int i=0;i<n;i++){
			arr[i] = sc.nextInt();
		}
		int k;
		System.out.println("Enter position to return");
		k = sc.nextInt();
		 KthSmallest(arr,0,n-1,k);
		//System.out.println("KthSmallest is " + KthSmallest(arr,0,n-1,k));
	}
}
