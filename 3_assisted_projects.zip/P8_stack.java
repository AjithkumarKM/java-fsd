package assisted_programs3;

class Stack{
	static final int size = 1000;
	int top;
	int[] arr = new int[size];
	
	Stack(){
		this.top = -1;
	}
	
	boolean isfull(){
		return top>1000;
	}
	
	boolean isEmpty(){
		return top<0;
	}
	
	boolean push(int data){
		if(isfull()){
			System.out.println("Stack is full(oveflow)");
			return false;
		}
		else{
			arr[++top] = data;
			System.out.println(data + " Pushed to stack");
			return true;
		}
	}
	
	int pop(){
		if(isEmpty()){
			System.out.println("Stack is empty(Underflow)");
			return 0;
		}
		else{
			System.out.println("\nPopped element");
			return arr[top--];
		}
	}
	void display(){
		System.out.println("\nDisplaying stack");
		for(int i=0;i<=top;i++){
			System.out.print(" " + arr[i]);
		}
	}
	void peek(){
		System.out.println("\nThe peek element is " + arr[top]);
	}
}

public class P8_stack {

	public static void main(String args[]){
		Stack s = new Stack();
		s.push(4);
		s.push(2);
		s.push(7);
		s.push(11);
		System.out.println(s.pop());
		s.peek();
		s.display();
	}
	
}
