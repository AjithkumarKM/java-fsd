package assisted_programs3;

class DoublyList{

	Node head;
	class Node{
		int data;
		Node next;
		Node prev;
		Node(int data){
			this.data = data;
		}
	}
	
	DoublyList insertFirst(DoublyList list, int data){
		Node new_node = new Node(data);
		new_node.next = list.head;
		new_node.prev = null;
		if(list.head != null){
			list.head.prev = new_node;
		}
		list.head = new_node;
		return list;
	}
	
	DoublyList insertAfter(DoublyList list, int pos, int data){
		Node new_node = new Node(data);
		new_node.next = list.head;
		new_node.prev = null;
		if(list.head == null){
			list.head = new_node;
			return list;
		}
		
		Node temp = list.head;
		Node prev = null;
		while(temp.next!=null){
			if(temp.data == pos){
				prev = temp;
				temp = temp.next;
				break;	
			}
			temp = temp.next;
		}
		
		if(prev == null){
			System.out.println("There is no element present");
			return list;
		}
		
		prev.next = new_node;
		new_node.next = temp;
		temp.prev = new_node;
		new_node.prev = prev;
		
		return list;
	}
	
	DoublyList insertLast(DoublyList list, int data){
		Node new_node = new Node(data);
		new_node.next = list.head;
		new_node.prev = null;
		if(list.head == null){
			list.head = new_node;
			return list;
		}
		
		Node temp = list.head;
		while(temp.next!=null){
			temp = temp.next;
		}
		new_node.next = null;
		temp.next = new_node;
		new_node.prev = temp;
		return list;
	}
	
	void display(DoublyList list){
		Node temp = list.head;
		Node last = null;
		System.out.println("Displaying data");		
		while(temp!=null){
			System.out.println(temp.data);
			last = temp;
			temp = temp.next;
		}
		
		System.out.println("Displaying data from reverse");		
		while(last!=null){
			System.out.println(last.data);
			last = last.prev;
		}

	}
}

public class P7_DoublyLinkedList {

	public static void main(String args[]){
		
		DoublyList d = new DoublyList();
		d = d.insertFirst(d, 5);
		d = d.insertFirst(d, 4);
		d = d.insertFirst(d, 3);
		d.display(d);
		
		d = d.insertAfter(d, 4, 6);
		d = d.insertAfter(d, 3, 1);
		d = d.insertLast(d,9);
		d = d.insertLast(d,11);
		
		d.display(d);
	}
}
