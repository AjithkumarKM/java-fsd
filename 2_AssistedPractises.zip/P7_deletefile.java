package assisted_projects2;

import java.io.File;
import java.io.IOException;

public class P7_deletefile {

	public static void main(String args[]) throws IOException{
		File f = new File("D://JAVA//exercise//newfile3.txt");
		if(f.createNewFile()){
			System.out.println("File is successfully created");
		}
		else{
			System.out.println("File is not created");
		}
		if(f.delete()){
			System.out.println("File is successfully deleted");
		}
		else{
			System.out.println("File is not deleted");
		}
	}
}
