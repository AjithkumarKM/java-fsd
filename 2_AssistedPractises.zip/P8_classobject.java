package assisted_projects2;

class Student_cls{
	int regno;
	String name;
	String dept;
	
	Student_cls(int regno,String name,String dept){
		this.regno = regno;
		this.name = name;
		this.dept = dept;
	}
	
	int getRegno(){
		return this.regno;
	}
	String getName(){
		return this.name;
	}
	String getDept(){
		return this.dept;
	}	
	
	public String toString(){
		return this.regno + " " + this.name + " " + this.dept;
	}
}

public class P8_classobject {

	public static void main(String args[]){
		Student_cls s = new Student_cls(3007,"Ajith","CT");
		
		System.out.println(s.getDept());
		System.out.println(s.getName());
		System.out.println(s.getRegno());
		
		System.out.println(s);
	}
}
