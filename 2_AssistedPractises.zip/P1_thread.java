package assisted_projects2;

class ByThreadClass extends Thread{
	public void run(){
		System.out.println("Thread creation by extending thread class");
//		try{
//			Thread.sleep(300);
//		}
//		catch(Exception e){
//			System.out.println("Caught thread exception");
//		}
//		System.out.println("Thread creation by extending thread class 2");
	}
}

class ByRunnable implements Runnable{
	public void run(){
		System.out.println("Thread creation by implementing runnable interface");
	}
}

public class P1_thread {

	public static void main(String args[]){
		ByThreadClass t1 = new ByThreadClass();
		System.out.println("Starting thread t1");
		t1.start();
		
		ByRunnable r = new ByRunnable();
		Thread t2 = new Thread(r);
		System.out.println("Starting thread t2");
		t2.start();
	}
}
