package assisted_projects2;

class car{
	String company;
	String model;
	
	car(String company,String model){
		this.company = company;
		this.model = model;
	}
	
	void display(){
		System.out.println(this.company + " " + this.model);
	}
}

class two_wheeler extends car{
	int speed;
	
	two_wheeler(String company,String model,int speed){
		super(company,model);
		this.speed = speed;
	}
	
	void display_specs(){
		System.out.println(company + " " + model + " " + this.speed);
	}	
}

public class P8_inheritance {

	public static void main(String args[]){
		two_wheeler v = new two_wheeler("Yamaha","R15 V4",170);
		System.out.println(v.company);
		System.out.println(v.model);
		System.out.println(v.speed);
		v.display();
		v.display_specs();
	}
}
