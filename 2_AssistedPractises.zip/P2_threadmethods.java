package assisted_projects2;

class CreateThread extends Thread{
	public void run(){
		System.out.println("Hello world");
		try{
			Thread.sleep(1000);
		}
		// sleep throws interrupted exception
		catch(InterruptedException e){
			System.out.println(e.getMessage());
		}
		System.out.println("Universe is big");
	}
}

public class P2_threadmethods {

	public static void main(String args[]){
		CreateThread t1 = new CreateThread();
		System.out.println("Starting thread 1");
		t1.start();
		
		CreateThread t2 = new CreateThread();
		System.out.println("Starting thread 2");
		t2.start();
	}
}
