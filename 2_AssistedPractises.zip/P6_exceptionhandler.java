package assisted_projects2;
import java.util.Scanner;

class Display extends Exception{
	String s;
	Display(String msg){
		this.s = msg;
	}
	public String toString(){
		return this.s;
	}
}

public class P6_exceptionhandler{

	static int divide(int a,int b) throws Display {
		if(b==0)
			throw new Display("Denominator cannot be zero");
		else 
			return a/b;
	}
	
	public static void main(String args[]){

		Scanner sc = new Scanner(System.in);
		int n1;
		int n2;
		int n3;
		
		System.out.println("Enter n1: ");
		n1 = sc.nextInt();
		System.out.println("Enter n2: ");
		n2 = sc.nextInt();
		
		try{
			n3 = divide(n1,n2);
			System.out.println("the division is " + n3);
		}
		catch(Exception e){
			System.out.println("Caught exception :: " + e);
		}
		finally{
			System.out.println("Finally block is executed");
		}
		
		sc.close();
	}
}