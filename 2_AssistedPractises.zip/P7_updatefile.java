package assisted_projects2;

import java.io.*;

public class P7_updatefile {

	public static void main(String args[]) throws IOException{
	
		File f = new File("D://JAVA//exercise//newfile2.txt");
		FileReader fr = null;
		BufferedReader br = null;
		String allLine = "";
		String newAllLine = "";
		try{
			fr = new FileReader(f);
			br = new BufferedReader(fr);
			String line = br.readLine();
			while(line != null){
				System.out.println(line);
				allLine += line + System.lineSeparator();
				System.out.println(allLine);
				line = br.readLine();
			}
			System.out.println("All line " + allLine);
			newAllLine = allLine.replaceAll("earth", "world");
			System.out.println("new All line " + newAllLine);
		}
		catch(FileNotFoundException e){
			e.getStackTrace();
		}
		catch(IOException e){
			e.getStackTrace();
		}
		catch(Exception e){
			e.getStackTrace();
		}
		finally{
			FileWriter fw = new FileWriter("D://JAVA//exercise//newfile2.txt");
			fw.write(newAllLine);
			fw.close();
		}
	}
}
