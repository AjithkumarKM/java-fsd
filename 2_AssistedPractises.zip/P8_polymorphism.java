package assisted_projects2;

class Course{
	String name;
	int duration;
	
	Course(String name, int duration){
		this.name = name;
		this.duration = duration;
	}
	
	void display(){
		System.out.println(this.duration + " " + this.name);
	}
	
	void display(String platform){
		System.out.println(this.duration + " " + this.name + " " + platform);
	}
	
	void display(String platform, String author){
		System.out.println(this.duration + " " + this.name + " " + platform + " " + author);
	}
}

public class P8_polymorphism {

	public static void main(String args[]){
		Course c = new Course("Python",7);
		c.display();
		c.display("Talentnext");
		c.display("Talentnext", "xyzatm");
	}
}
