package assisted_projects2;

abstract class Movies{
	String name;
	int year;
	
	Movies(String name,int year){
		this.name = name;
		this.year = year;
	}
	
	void display(){
		System.out.println(this.name + " " + this.year);
	}
	
	abstract void details();
}

class Cast extends Movies{
	String actor;
	
	Cast(String name,int year,String actor){
		super(name,year);
		this.actor = actor;
	}
	
	void details(){
		System.out.println(name + " " + year + " " + this.actor);
	}
}

public class P8_abstraction {

	public static void main(String args[]){
		Movies m = new Cast("Kaithi",2019,"Karthi");
		m.display();
		m.details();
	}
}
