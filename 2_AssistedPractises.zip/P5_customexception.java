package assisted_projects2;

import java.util.Scanner;

class DisplayMsg extends Exception{
	DisplayMsg(String msg){
		super(msg);
	}
}

public class P5_customexception{

	static int divide(int a,int b) throws DisplayMsg {
		if(b==0)
			throw new DisplayMsg("Denominator cannot be zero");
		else 
			return a/b;
	}
	
	public static void main(String args[]){

		Scanner sc = new Scanner(System.in);
		int n1;
		int n2;
		int n3;
		
		System.out.println("Enter n1: ");
		n1 = sc.nextInt();
		System.out.println("Enter n2: ");
		n2 = sc.nextInt();
		
		try{
			n3 = divide(n1,n2);
			System.out.println("the division is " + n3);
		}
		catch(Exception e){
			System.out.println("Caught exception :: " + e.getMessage());
		}
		finally{
			System.out.println("Finally block is executed");
		}
		
		sc.close();
	}
}