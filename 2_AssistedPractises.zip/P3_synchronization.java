package assisted_projects2;

class Student{
	int regno = 3007;
	String name = "Ajith";
	//synchronized void display(){
	void display(){
		for(int i=0;i<3;i++){
		System.out.println(i + "regno " + regno + " name " + name);
		try{
			Thread.sleep(100);
		}
		catch(Exception e){
			System.out.println("Interrupted exception");
		}
		//System.out.println("Student details displayed");
		}
	}
}

//class Thread1 extends Thread{
//	Student s;
//	Thread1(Student s){
//		this.s = s;
//	}
//	public void run(){
//		s.display();
//	}
//}
//
//class Thread2 extends Thread{
//	Student s;
//	Thread2(Student s){
//		this.s = s;
//	}
//	public void run(){
//		s.display();
//	}
//}

class Thread1 extends Thread{
	Student s;
	Thread1(Student s){
		this.s = s;
	}
	public void run(){
		synchronized(s){
			s.display();
		}
	}
}

public class P3_synchronization {

	public static void main(String args[]){
		
		Student s= new Student();
		
		Thread1 t = new Thread1(s);
		//Thread2 t1 = new Thread2(s);
		Thread1 t1 = new Thread1(s);
		
		t.start();
		t1.start();
		
	}
}
