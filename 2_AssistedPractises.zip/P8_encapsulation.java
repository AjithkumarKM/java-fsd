package assisted_projects2;

class Details{
	private int sec_no;
	private String place;
	private int ph_no;
	
	public int getSec_no() {
		return sec_no;
	}
	public void setSec_no(int sec_no) {
		this.sec_no = sec_no;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public int getPh_no() {
		return ph_no;
	}
	public void setPh_no(int ph_no) {
		this.ph_no = ph_no;
	}
	
	
}

public class P8_encapsulation {

	public static void main(String args[]){
		Details d = new Details();
		d.setPh_no(67348723);
		d.setPlace("Chennai");
		d.setSec_no(8703);
		System.out.println(d.getPh_no());
		System.out.println(d.getPlace());
		System.out.println(d.getSec_no());
	}
}
