package assisted_projects2;
import java.util.*;

public class P4_trycatch {

	public static void main(String args[]){
		
		Scanner sc = new Scanner(System.in);
		int n1;
		int n2;
		int n3;
		
		System.out.println("Enter n1: ");
		n1 = sc.nextInt();
		System.out.println("Enter n2: ");
		n2 = sc.nextInt();
		
		try{
			n3 = n1 / n2;
			System.out.println("the division is " + n3);
		}
		catch(ArithmeticException e){
			System.out.println("Arithmetic Exception is handled");
		}
		catch(Exception e){
			System.out.println("Exception is handled");
		}
		finally{
			System.out.println("Finally block is executed");
		}
		n3 = n1 + n2;
		System.out.println("the sum is " + n3);
		sc.close();
	}
}
