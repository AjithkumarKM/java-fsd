package assisted_projects2;

interface car_s{
	
	default void display1(){
		System.out.println("Inside car_s");
	}
}

interface car1 extends car_s{

	default void display(){
		System.out.println("Inside car1");
	}
}

interface car2 extends car_s{

	default void display(){
		System.out.println("Inside car2");
	}
}


public class P9_diamond implements car1, car2{

	public void display(){
		System.out.println("Inside P9_diamond class");
	}
	
	public static void main(String args[]){
		
		P9_diamond p = new P9_diamond();
		p.display();
		p.display1();
	}

}
