package assisted_projects2;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

class File_read{
	public ArrayList getLines(String filename){
		ArrayList<String> l = new ArrayList<String>();
		try{
			l = (ArrayList) Files.readAllLines(Paths.get(filename));
		}
		catch(IOException e){
			e.getMessage();
		}
		return l;
	}
}

public class P7_readFile {

	public static void main(String args[]){
		
		String filepath = "D://JAVA//exercise//newfile2.txt";
		ArrayList<String> l = new File_read().getLines(filepath);
		System.out.println(l);
	}
}
