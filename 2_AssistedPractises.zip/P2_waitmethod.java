package assisted_projects2;


class ThreadWait{
	synchronized public void display(){
		 System.out.println("1st stmt of thread");
		try{
			wait();
		}
		// wait throws interrupted exception
		catch(InterruptedException e){
			System.out.println(e.getMessage());
		}
		System.out.println("end stmt of thread");
	}
	synchronized public void stopWait(){
		System.out.println("Stopwait method ...");
		notify();
	}
}

public class P2_waitmethod extends Thread{

	public static void main(String args[]){
		
		ThreadWait t = new ThreadWait();

		System.out.println("Creating new thread");
		new Thread(){
			public void run(){
				t.display();
			}
		}.start();
		
		System.out.println("Creating new thread 2");
		new Thread(){
			public void run(){
				t.stopWait();
			}
		}.start();
		
	}
}
