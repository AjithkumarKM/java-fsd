package assisted_projects2;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class P7_createfile {

	public static void main(String args[]) throws IOException{
		
		File f = new File("D://JAVA//exercise//newfile2.txt");
		if(f.createNewFile())
			System.out.println("File is successfully created");
		else
			System.out.println("File is cannot be created");
		
		FileWriter fw = new FileWriter(f);
		fw.write("Hello world");
		fw.close();
	}
}
