package com.example.demo;

import org.springframework.context.ApplicationEvent;

// this class will create custom event
public class MsgSource extends ApplicationEvent{

	public MsgSource(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}
	
}
