package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.Lifecycle;

@SpringBootApplication
public class DemoCustomEvents1Application {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(DemoCustomEvents1Application.class, args);
		
		((Lifecycle) context).start();
		
		PublishEvent eventPublish = (PublishEvent) context.getBean("publishEvent");
		eventPublish.publish(new MsgSource(new MsgEvent()));
		
		((Lifecycle) context).stop();
	}

}
