package com.example.demo;

public class MsgEvent {

	private String str ="Hello wordl, simple event msg";
	
	public String getStr() {
		return str;
	}
}
