package com.example.demo;

import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component
public class EventHandler1 implements ApplicationListener<MsgSource>{

	@Override
	public void onApplicationEvent(MsgSource event) {
		
		Object source  = event.getSource();
		if(source instanceof MsgEvent) {
			MsgEvent msg = (MsgEvent) source;
			
			System.out.println("Hadler 1 : " + msg.getStr());
		}
	}

}
