package projects;
import java.util.*;

public class Calculator {

	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		
		double a,b,c;
		int op;

		System.out.println("\nEnter value of a ..");
		a = sc.nextDouble();
		System.out.println("Enter value of b ..");
		b = sc.nextDouble();
		
		while(true){
			
			System.out.println("\nEnter the operation to be performed ..");
			System.out.println("1.Addition  2.subtraction  3.Multiplication  4.Division");
			op = sc.nextInt();
	
			if(op == 1){
				c = a + b;
				System.out.println("Addition of " + a + " and " + b + " is " + c);
				break;
			}

			else if(op == 2){
				c = a - b;
				System.out.println("Subtraction of " + a + " and " + b + " is " + c);
				break;
			}

			else if(op==3){
				c = a * b;
				System.out.println("Multiplication of " + a + " and " + b + " is " + c);
				break;
			}

			else if(op==4){
				c = a / b;
				System.out.println("Division of " + a + " and " + b + " is " + c);
				break;
			}

			else{
				System.out.println("Invalid operation.. Enter valid option");
			}
		}
	}
}
