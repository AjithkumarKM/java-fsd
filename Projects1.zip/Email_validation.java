package projects;
import java.util.*;
import java.util.regex.Pattern;

public class Email_validation {

	public static void main(String args[]){
		
		Scanner sc = new Scanner(System.in);
		
		String[] emails = new String[7];
		
		emails[0] = "johnbenito@gmail.com";
		emails[1] = "billgates@outlook.com";
		emails[2] = "jacksparrow@gmail.com";
		emails[3] = "johnkennedy@gmail.com";
		emails[4] = "elonmusk@outlook.com";
		emails[5] = "ironman@gmail.com";
		emails[6] = "davidbilla@gmail.com";
		
		String check_mail;
		while(true){
			System.out.println("Enter email to be checked ..");
			check_mail = sc.next();
			if(Pattern.matches("^[A-Za-z0-9+_.-]+@(.+)$", check_mail))
				break;
			else
				System.out.println("Email is invalid.. Enter valid email address ..");
		}
		
		int flag = 0;
		for(String s: emails){
			if(s.equals(check_mail)){
				System.out.println("Provided Email is in the list");
				flag = 1;
				break;
			}
		}
		if(flag == 0)
			System.out.println("Provided Email is not in the list");
	}
}
